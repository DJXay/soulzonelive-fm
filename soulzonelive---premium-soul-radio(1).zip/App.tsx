
import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import MainPlayer from './components/MainPlayer';
import AIDJCompanion from './components/AIDJCompanion';
import Header from './components/Header';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState('on-air');

  return (
    <div className="relative min-h-screen bg-[#020617] text-slate-100 flex flex-col md:flex-row overflow-hidden">
      {/* Background Decorative Elements */}
      <div className="fixed top-[-10%] left-[-10%] w-[60%] h-[60%] bg-purple-600/10 rounded-full blur-[160px] pointer-events-none"></div>
      <div className="fixed bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-blue-600/5 rounded-full blur-[140px] pointer-events-none"></div>
      
      {/* Sidebar Navigation */}
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />

      <div className="flex-1 flex flex-col min-w-0 relative h-screen overflow-y-auto md:overflow-hidden">
        <Header />
        
        <main className="flex-1 overflow-y-auto p-4 md:p-8 flex flex-col lg:flex-row gap-8">
          <div className="flex-1 flex flex-col gap-8 max-w-5xl mx-auto w-full">
            {activeTab === 'on-air' && <MainPlayer />}
            
            {activeTab !== 'on-air' && (
              <div className="glass-premium p-12 rounded-3xl text-center">
                <h2 className="text-3xl font-bold mb-4 capitalize">{activeTab.replace('-', ' ')}</h2>
                <p className="opacity-50">This section is being synchronized with the SOULZONELIVE satellite stream...</p>
              </div>
            )}
            
            <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pb-8">
               <FeatureCard 
                title="Weekly Chart" 
                subtitle="Soulful Selects" 
                img="https://images.unsplash.com/photo-1493225255756-d9584f8606e9?auto=format&fit=crop&q=80&w=400"
               />
               <FeatureCard 
                title="Deep Sessions" 
                subtitle="Archive Highlight" 
                img="https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&q=80&w=400"
               />
               <FeatureCard 
                title="Retro Wave" 
                subtitle="Classic Soul Vibes" 
                img="https://images.unsplash.com/photo-1459749411177-042180ce673c?auto=format&fit=crop&q=80&w=400"
               />
            </section>
          </div>

          <aside className="w-full lg:w-80 shrink-0 lg:h-full lg:pb-8 flex flex-col">
            <AIDJCompanion />
          </aside>
        </main>

        <footer className="p-8 md:p-12 border-t border-white/5 bg-black/20 text-center md:text-left mt-auto">
          <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div>
              <p className="text-sm text-gray-400">
                &copy; 2013–2026 <span className="text-white font-bold">SOULZONELIVE</span>, Covington GA – All Rights Reserved.
              </p>
              <p className="text-[10px] text-gray-500 mt-1 uppercase tracking-tighter">
                SOULZONELIVE is a fully Registered US Federal Trademark.
              </p>
            </div>
            <div className="md:text-right space-y-2">
              <div className="space-x-4 text-sm font-medium">
                <a href="https://neosoulzonelive.neocities.org/privacy-policy.html" className="text-purple-400 hover:text-purple-300 transition-colors">Privacy Policy</a>
                <span className="text-gray-700">|</span>
                <a href="https://neosoulzonelive.neocities.org/terms-of-use.html" className="text-purple-400 hover:text-purple-300 transition-colors">Terms of Use</a>
              </div>
              <p className="text-xs text-gray-400">
                Contact: <a href="mailto:soulzonelive@protonmail.com" className="hover:underline">soulzonelive@protonmail.com</a>
              </p>
            </div>
          </div>
        </footer>
      </div>

      <style>{`
        /* Premium Glassmorphism Enhancements */
        .glass-premium {
          background: rgba(255, 255, 255, 0.02);
          backdrop-filter: blur(20px) saturate(160%);
          border: 1px solid rgba(255, 255, 255, 0.08);
          box-shadow: 
            0 8px 32px 0 rgba(0, 0, 0, 0.4),
            inset 0 0 0 1px rgba(255, 255, 255, 0.03);
          position: relative;
        }
        
        /* Subtle Inner Glow Border Effect */
        .glass-premium::before {
          content: "";
          position: absolute;
          inset: 0;
          border-radius: inherit;
          padding: 1px;
          background: linear-gradient(135deg, rgba(255,255,255,0.1), transparent 40%, transparent 60%, rgba(124,58,237,0.1));
          -webkit-mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
          mask: linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
          -webkit-mask-composite: xor;
          mask-composite: exclude;
          pointer-events: none;
        }

        .purple-glow-text {
          text-shadow: 0 0 30px rgba(124, 58, 237, 0.5);
        }

        .animate-float {
          animation: float 8s ease-in-out infinite;
        }

        @keyframes float {
          0%, 100% { transform: translateY(0px); }
          50% { transform: translateY(-12px); }
        }
      `}</style>
    </div>
  );
};

const FeatureCard: React.FC<{ title: string; subtitle: string; img: string }> = ({ title, subtitle, img }) => (
  <div className="glass-premium rounded-2xl overflow-hidden group hover:border-purple-500/40 transition-all duration-500 cursor-pointer">
    <div className="h-44 overflow-hidden relative">
      <img src={img} alt={title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000" />
      <div className="absolute inset-0 bg-gradient-to-t from-[#020617] via-[#020617]/40 to-transparent opacity-80"></div>
    </div>
    <div className="p-5">
      <h3 className="font-bold text-lg text-white/90">{title}</h3>
      <p className="text-xs font-medium uppercase tracking-widest opacity-40 mt-1">{subtitle}</p>
    </div>
  </div>
);

export default App;
