
import React from 'react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  const navItems = [
    { id: 'on-air', label: 'On Air', showDot: true },
    { id: 'listen', label: 'Listen', href: "https://neosoulzonelive.neocities.org/home#listen" },
    { id: 'schedule', label: 'Schedule', href: "https://neosoulzonelive.neocities.org/home#schedule" },
    { id: 'playlists', label: 'Playlists', href: "https://neosoulzonelive.neocities.org/home#history" },
    { id: 'shows', label: 'Shows', href: "https://neosoulzonelive.neocities.org/home#schedule" },
  ];

  return (
    <nav className="w-full md:w-24 bg-black/40 backdrop-blur-2xl border-b md:border-b-0 md:border-r border-white/5 flex flex-row md:flex-col items-center justify-between md:justify-start py-4 md:py-8 px-6 md:px-0 z-50">
      <div className="w-11 h-11 bg-purple-600 rounded-xl flex items-center justify-center shadow-lg shadow-purple-600/30 mb-0 md:mb-12">
        <span className="font-black text-xl italic text-white leading-none">S</span>
      </div>

      <div className="flex flex-row md:flex-col items-center gap-6 md:gap-10">
        {navItems.map((item) => (
          <button
            key={item.id}
            onClick={() => item.href ? window.location.href = item.href : setActiveTab(item.id)}
            className={`group relative flex flex-col items-center transition-all duration-300 ${
              activeTab === item.id ? 'text-purple-400' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            {item.showDot && (
              <div className="w-2 h-2 bg-red-500 rounded-full mb-1 shadow-[0_0_8px_#ef4444] animate-pulse"></div>
            )}
            <span className="text-[10px] font-black uppercase tracking-[0.2em]">{item.label}</span>
            {activeTab === item.id && !item.href && (
              <div className="absolute -bottom-2 md:bottom-auto md:-right-4 w-1 h-1 md:w-1 md:h-6 bg-purple-600 rounded-full"></div>
            )}
          </button>
        ))}
      </div>

      <div className="hidden md:flex flex-col items-center gap-6 mt-auto">
        <button className="text-slate-600 hover:text-white transition-colors">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
            <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5" />
          </svg>
        </button>
      </div>
    </nav>
  );
};

export default Sidebar;
