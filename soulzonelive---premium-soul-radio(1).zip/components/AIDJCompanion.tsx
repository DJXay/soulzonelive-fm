
import React from 'react';

const AIDJCompanion: React.FC = () => {
  return (
    <div className="glass-premium h-full min-h-[550px] lg:h-full rounded-[2rem] flex flex-col overflow-hidden border-l border-white/5">
      {/* Header section with updated branding */}
      <div className="p-5 border-b border-white/5 flex items-center justify-between bg-white/5">
        <div className="flex items-center gap-3">
          <div className="w-2.5 h-2.5 rounded-full bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.6)] animate-pulse"></div>
          <h3 className="font-bold text-xs uppercase tracking-[0.2em] text-purple-400">LIVE CHAT | DJ XAY</h3>
        </div>
        <div className="w-9 h-9 rounded-xl bg-purple-600/10 flex items-center justify-center border border-purple-500/20">
            <span className="text-lg">💬</span>
        </div>
      </div>

      {/* Cbox Live Chat Widget Container */}
      <div className="flex-1 w-full bg-black/20">
        <iframe 
          src="https://www3.cbox.ws/box/?boxid=3552207&boxtag=A2bik9" 
          width="100%" 
          height="100%" 
          style={{ minHeight: '450px', border: 'none' }}
          allowTransparency={true} 
          allow="autoplay" 
          frameBorder="0" 
          marginHeight={0} 
          marginWidth={0} 
          scrolling="auto"
          title="SOULZONELIVE Live Chat"
          className="opacity-90 hover:opacity-100 transition-opacity"
        ></iframe>
      </div>

      {/* Small footer note for the chat area */}
      <div className="p-3 bg-black/40 border-t border-white/5 text-center">
        <p className="text-[9px] uppercase tracking-widest text-slate-500 font-bold">
          Keep it soulful. Respect the vibe.
        </p>
      </div>
      
      <style>{`
        /* Ensure the iframe container takes up the remaining space properly */
        .glass-premium iframe {
          display: block;
        }
      `}</style>
    </div>
  );
};

export default AIDJCompanion;
