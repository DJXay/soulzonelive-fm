
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="h-20 flex items-center justify-between px-8 z-40">
      <div className="flex-1 flex items-center gap-8">
        <div className="relative w-full max-w-md hidden xl:block">
          <input 
            type="text" 
            placeholder="Search soul archives..." 
            className="w-full bg-white/5 border border-white/10 rounded-full py-2.5 px-12 focus:outline-none focus:border-purple-500/50 transition-colors"
          />
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-5 h-5 absolute left-4 top-1/2 -translate-y-1/2 opacity-30">
            <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-5.197-5.197m0 0A7.5 7.5 0 105.196 5.196a7.5 7.5 0 0010.607 10.607z" />
          </svg>
        </div>

        <nav className="hidden lg:flex items-center gap-6">
          <a href="https://neosoulzonelive.neocities.org/home#listen" className="text-xs font-black uppercase tracking-[0.2em] text-white/60 hover:text-purple-400 transition-colors">Listen</a>
          <a href="https://neosoulzonelive.neocities.org/home#schedule" className="text-xs font-black uppercase tracking-[0.2em] text-white/60 hover:text-purple-400 transition-colors">Schedule</a>
          <a href="https://neosoulzonelive.neocities.org/home#history" className="text-xs font-black uppercase tracking-[0.2em] text-white/60 hover:text-purple-400 transition-colors">History</a>
        </nav>
      </div>

      <div className="flex items-center gap-6">
        <button className="relative group">
          <div className="absolute -inset-2 bg-purple-500 rounded-full opacity-0 group-hover:opacity-10 transition-opacity"></div>
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6 opacity-60">
            <path strokeLinecap="round" strokeLinejoin="round" d="M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75v-.7V9A6 6 0 006 9v.75a8.967 8.967 0 01-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0" />
          </svg>
        </button>

        <div className="flex items-center gap-3 bg-white/5 rounded-full p-1 pr-4 border border-white/5">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-purple-500 to-indigo-500 flex items-center justify-center font-bold text-xs">SZ</div>
          <span className="text-sm font-medium opacity-80 hidden sm:inline">SoulZone User</span>
        </div>
      </div>
    </header>
  );
};

export default Header;
