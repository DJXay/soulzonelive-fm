
import React from 'react';

const MainPlayer: React.FC = () => {
  return (
    <div className="relative group">
      {/* Dynamic Glow behind player */}
      <div className="absolute -inset-2 bg-gradient-to-br from-purple-600/20 via-blue-600/10 to-pink-600/10 rounded-[2.5rem] blur-2xl opacity-40 group-hover:opacity-60 transition duration-1000"></div>
      
      <div className="glass-premium relative p-8 md:p-12 rounded-[2.5rem] flex flex-col items-center lg:items-start text-center lg:text-left animate-float overflow-hidden">
        
        {/* Abstract Background Elements */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-purple-500/5 rounded-full blur-3xl -mr-32 -mt-32"></div>

        <div className="relative z-10 w-full">
          <div className="flex items-center justify-center lg:justify-start gap-3 mb-6">
            <div className="flex h-2.5 w-2.5 relative">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500 shadow-[0_0_10px_#ef4444]"></span>
            </div>
            <span className="text-[10px] font-black uppercase tracking-[0.4em] text-purple-400/80">Broadcasting Worldwide</span>
          </div>

          <h1 className="text-5xl md:text-8xl font-black mb-6 tracking-tighter leading-none">
            SOUL<span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-indigo-400 purple-glow-text">ZONE</span>LIVE
          </h1>
          
          <p className="text-lg md:text-xl font-light mb-10 opacity-70 max-w-2xl leading-relaxed">
            No Algorithms. No Commercials. Just Soul. <br />
            <span className="text-white/90 font-medium">Curated by hand from a 50,000-track archive.</span>
          </p>

          <div className="flex flex-col items-center lg:items-start gap-8 w-full">
            {/* Redesigned High-Impact Live Card */}
            <div className="w-full max-w-2xl bg-gradient-to-br from-purple-900/40 to-black/60 rounded-[2rem] p-8 border border-white/10 shadow-2xl relative overflow-hidden group/card hover:border-purple-500/30 transition-all duration-500">
              <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] opacity-10"></div>
              
              <div className="relative z-10 flex flex-col md:flex-row items-center gap-8">
                {/* Visual "Now Playing" Indicator */}
                <div className="relative w-32 h-32 md:w-40 md:h-40 flex-shrink-0">
                  <div className="absolute inset-0 bg-purple-600/20 rounded-full animate-pulse"></div>
                  <div className="absolute inset-4 bg-gradient-to-tr from-purple-600 to-indigo-600 rounded-full flex items-center justify-center shadow-2xl group-hover/card:scale-105 transition-transform duration-500">
                    <span className="text-5xl md:text-6xl">▶</span>
                  </div>
                  {/* Decorative orbital rings */}
                  <div className="absolute inset-0 border border-white/5 rounded-full animate-[spin_10s_linear_infinite]"></div>
                  <div className="absolute -inset-2 border border-purple-500/10 rounded-full animate-[spin_15s_linear_infinite_reverse]"></div>
                </div>

                <div className="flex-1 text-center md:text-left">
                  <h2 className="text-2xl md:text-3xl font-black mb-2 tracking-tight">LIVE STREAM</h2>
                  <p className="text-purple-400 font-bold text-sm mb-4 tracking-widest uppercase">Hand-Curated Soul</p>
                  
                  <div className="flex items-center justify-center md:justify-start gap-1 h-6 mb-6 opacity-60">
                    {[...Array(12)].map((_, i) => (
                      <div 
                        key={i} 
                        className="w-1 bg-white rounded-full animate-bounce" 
                        style={{ height: `${20 + Math.random() * 80}%`, animationDelay: `${i * 0.05}s` }}
                      ></div>
                    ))}
                  </div>

                  <a 
                    href="https://neosoulzonelive.neocities.org/home#listen" 
                    className="inline-flex items-center gap-3 bg-white text-black font-black px-10 py-4 rounded-full hover:bg-purple-400 hover:text-white transition-all transform hover:scale-105 active:scale-95 shadow-xl"
                  >
                    <span>LISTEN LIVE</span>
                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor" className="w-5 h-5">
                      <path fillRule="evenodd" d="M4.5 5.653c0-1.426 1.529-2.33 2.779-1.643l11.54 6.348c1.295.712 1.295 2.573 0 3.285L7.28 19.991c-1.25.687-2.779-.217-2.779-1.643V5.653z" clipRule="evenodd" />
                    </svg>
                  </a>
                </div>
              </div>
            </div>
            
            <div className="w-full flex flex-wrap justify-center lg:justify-start gap-3 opacity-60 hover:opacity-100 transition-opacity">
              <PlayerActionButton href="https://neosoulzonelive.neocities.org/home#schedule" label="Schedule" />
              <PlayerActionButton href="https://neosoulzonelive.neocities.org/home#history" label="Playlists" />
              <PlayerActionButton href="https://neosoulzonelive.neocities.org/home#schedule" label="Shows" />
              <PlayerActionButton href="https://neosoulzonelive.neocities.org/home#requests" label="Requests" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

interface ActionButtonProps {
  label: string;
  href: string;
}

const PlayerActionButton: React.FC<ActionButtonProps> = ({ label, href }) => {
  return (
    <a 
      href={href}
      className="flex items-center justify-center py-2.5 px-5 rounded-xl font-bold text-[10px] uppercase tracking-widest text-center transition-all duration-300 bg-white/5 border border-white/5 text-slate-400 hover:text-white hover:bg-white/10"
    >
      {label}
    </a>
  );
};

export default MainPlayer;
